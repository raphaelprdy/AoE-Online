from encodings import utf_8
from pickle import TRUE
from socket import *
import time
import subprocess


PORT = 5000
ADDR = "127.0.0.1"
listeningAddr = (ADDR, PORT)
serverAddr = ("127.0.0.1", 5001)

message = "je suis le client 1"
msg_connect = "/connect"

sockfd = socket(AF_INET, SOCK_DGRAM)
sockfd.bind(listeningAddr)


subprocess.Popen(['./socketenc_main', '/'], shell=True)
time.sleep(1)

sockfd.sendto(msg_connect.encode("utf8"), serverAddr)
time.sleep(1)
sockfd.sendto(message.encode("utf-8"), serverAddr)

while TRUE:
    data = sockfd.recvfrom(128)[0]
    data = data.decode("utf8")
    data = data[:-1]
    print("received message: " + str(data))